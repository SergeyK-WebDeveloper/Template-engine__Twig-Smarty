The Text Extension
==================

The Text extension provides the following filters:

* ``truncate``
* ``wordwrap``

Installation
------------

First, :ref:`install the Extensions library<extensions-install>`. Next, add
the extension to Twig::

    $twig->addExtension(new Twig_Extensions_Extension_Text());
