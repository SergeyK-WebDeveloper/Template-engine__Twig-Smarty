Contributing is.js
==================

Thanks for considering to contribute is.js

- Please don't re-build minified library on your pull request.
- Be sure you've added tests if you are sending a new feature.
- I'll take care of the documentation and github page.

Cheers.
